package com.mini.sistemamininventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaMinInventarioApplicationTests {

    @Test
    void contextLoads() {
    }

}
