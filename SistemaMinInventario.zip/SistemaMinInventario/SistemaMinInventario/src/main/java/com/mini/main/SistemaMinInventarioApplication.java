package com.mini.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.mini")
@EntityScan("com.mini.entity")
@EnableJpaRepositories("com.mini.repository")
public class SistemaMinInventarioApplication {
    public static void main(String[] args) {
        SpringApplication.run(SistemaMinInventarioApplication.class, args);
    }
}
