package com.mini.service;

import com.mini.entity.Productos;
import com.mini.repository.ProductosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductosService {

    @Autowired
    private ProductosRepository productosRepository;

    public List<Productos> getAllProductos() {
        return productosRepository.findAll();
    }

    public Optional<Productos> getProductoById(Long id) {
        return productosRepository.findById(id);
    }

    public Productos createProducto(Productos producto) {
        return productosRepository.save(producto);
    }

    public Productos updateProducto(Long id, Productos producto) {
        if (productosRepository.existsById(id)) {
            producto.setId(id);
            return productosRepository.save(producto);
        } else {
            throw new RuntimeException("Producto no encontrado con ID: " + id);
        }
    }

    public void deleteProducto(Long id) {
        productosRepository.deleteById(id);
    }
}
