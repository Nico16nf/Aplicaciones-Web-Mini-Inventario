package com.mini.service;

import com.mini.entity.Proveedores;
import com.mini.repository.ProveedoresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProveedoresService {

    @Autowired
    private ProveedoresRepository proveedoresRepository;

    public List<Proveedores> getAllProveedores() {
        return proveedoresRepository.findAll();
    }

    public Optional<Proveedores> getProveedorById(int id) {
        return proveedoresRepository.findById(id);
    }

    public Proveedores createProveedor(Proveedores proveedor) {
        return proveedoresRepository.save(proveedor);
    }

    public Proveedores updateProveedor(int id, Proveedores proveedor) {
        if (proveedoresRepository.existsById(id)) {
            proveedor.setId(id);
            return proveedoresRepository.save(proveedor);
        } else {
            throw new RuntimeException("Proveedor no encontrado con ID: " + id);
        }
    }

    public void deleteProveedor(int id) {
        proveedoresRepository.deleteById(id);
    }
}

