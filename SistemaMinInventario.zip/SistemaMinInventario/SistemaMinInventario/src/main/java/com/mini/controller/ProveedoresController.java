package com.mini.controller;

import com.mini.entity.Proveedores;
import com.mini.service.ProveedoresService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/proveedores")
public class ProveedoresController {

    @Autowired
    private ProveedoresService proveedoresService;

    @GetMapping
    public List<Proveedores> getAllProveedores() {
        return proveedoresService.getAllProveedores();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Proveedores> getProveedorById(@PathVariable int id) {
        return proveedoresService.getProveedorById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Proveedores createProveedor(@RequestBody Proveedores proveedor) {
        return proveedoresService.createProveedor(proveedor);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Proveedores> updateProveedor(@PathVariable int id, @RequestBody Proveedores proveedor) {
        try {
            Proveedores updated = proveedoresService.updateProveedor(id, proveedor);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProveedor(@PathVariable int id) {
        proveedoresService.deleteProveedor(id);
        return ResponseEntity.noContent().build();
    }
}
