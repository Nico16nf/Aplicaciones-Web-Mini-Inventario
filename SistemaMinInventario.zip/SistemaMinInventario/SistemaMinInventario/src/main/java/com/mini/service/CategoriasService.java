package com.mini.service;


import com.mini.entity.Categorias;
import com.mini.repository.CategoriasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriasService {

    @Autowired
    private CategoriasRepository categoriasRepository;

    public List<Categorias> getAllCategorias() {
        return categoriasRepository.findAll();
    }

    public Optional<Categorias> getCategoriaById(int id) {
        return categoriasRepository.findById(id);
    }

    public Categorias createCategoria(Categorias categoria) {
        return categoriasRepository.save(categoria);
    }

    public Categorias updateCategoria(int id, Categorias categoria) {
        if (categoriasRepository.existsById(id)) {
            categoria.setId(id);
            return categoriasRepository.save(categoria);
        } else {
            throw new RuntimeException("Categoría no encontrada con ID: " + id);
        }
    }

    public void deleteCategoria(int id) {
        categoriasRepository.deleteById(id);
    }
}
